-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2018 at 06:54 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrolment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `admin_phone`, `created_at`, `updated_at`) VALUES
(2, 'Tanay Ghosh', 'tanay@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01688237537', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_11_17_065701_create_admin_tbl_table', 1),
(2, '2018_11_21_164526_create_student_tbl_table', 2),
(3, '2018_11_24_191736_create_teachers_tbl_table', 3),
(4, '2018_11_24_192529_create_teachers_tbl_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `student_tbl`
--

CREATE TABLE `student_tbl` (
  `student_id` int(10) UNSIGNED NOT NULL,
  `student_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_roll` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_fathername` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_mothername` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_admissionyear` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_tbl`
--

INSERT INTO `student_tbl` (`student_id`, `student_name`, `student_roll`, `student_fathername`, `student_mothername`, `student_email`, `student_phone`, `student_address`, `student_image`, `student_password`, `student_department`, `student_admissionyear`, `created_at`, `updated_at`) VALUES
(1, 'Kiron Osman', '1208028', 'Gazi Uddin', 'Fatema Begum', 'osman@gmail.com', '018888', 'kachua', 'image/rTAfxZPfj16akXIyBqyE.jpg', 'e10adc3949ba59abbe56e057f20f883e', '1', '2018-11-22', NULL, NULL),
(2, 'Saimoon Riad', '1108021', 'kazi saif', 'rokeya begum', 'saimon@gmail.com', '017777', 'dhaka', 'image/ZNdDrsLNYDgSlRJXznIW.jpg', 'e10adc3949ba59abbe56e057f20f883e', '3', '2018-11-22', NULL, NULL),
(3, 'Palash roy', '120833', 'hasira', 'maya', 'palasroy@gmail.com', '01877', 'cumilla', 'image/4zK4Gdl72gp4IK8t43TP.jpg', '123456', '5', '2018-11-22', NULL, NULL),
(4, 'roni', '2222', 'talib', 'sumaiya', 'roni@gmail.com', '5555', 'khulna', 'image/PR2MU7H5rSFPBCTUUOdr.jpg', 'e10adc3949ba59abbe56e057f20f883e', '3', '2018-11-22', NULL, NULL),
(5, 'rimon islam', '1208036', 'sohel rana', 'salma islam', 'rimon@gmail.com', '0174444444', 'tangail', 'image/ezfbXIDP0yZjVVy6aHyF.jpg', '123456', '2', '2018-11-15', NULL, NULL),
(8, 'gdfd', '11134', 'sfdsf', 'sdfsa', 'afd@gmail.com', '122', 'dfsg', 'image/5SOZ9kHQHtFWU1bgErDO.jpg', 'e10adc3949ba59abbe56e057f20f883e', '1', '2018-11-23', NULL, NULL),
(12, 'fds', '4444', 'fds', 'fgds', 'dfdf@gmail.com', '23', '5435', 'image/4uUFpsljHRabPQf9ZyaF.jpg', '202cb962ac59075b964b07152d234b70', '4', '2018-11-23', NULL, NULL),
(13, 'Kiron Osman', 'dsfsd', 'gdfgf', 'dsfg', 'f@gmail.com', 'gdfg', 'fgdg', 'image/7bFDUXQl8HqbjmzXKfxn.jpg', '698d51a19d8a121ce581499d7b701668', '2', '2018-11-25', NULL, NULL),
(14, 'blA', 'aaa', 'aaaa', 'aa', 'aa@gmail.com', 'aa', 'aaa', 'image/fjONpYYFjovrjYKrE7qJ.jpg', 'd41d8cd98f00b204e9800998ecf8427e', '3', '2018-11-01', NULL, NULL),
(15, 'ggg', 'ggg', 'ggg', 'ggg', 'ggg@gmail.com', '111', 'kachua', 'image/fBqYR6otUNs8hGkUmIRF.jpg', '698d51a19d8a121ce581499d7b701668', '3', '2018-11-02', NULL, NULL),
(16, 'Pritam Ghosh', '1108022', 'Tapan Ghosh', 'Dipaly Ghosh', 'pritamcsecou@gmail.com', '01758125411', 'Chandpur', 'image/J80A4H7wpnK9DIZuPmoO.jpg', 'e10adc3949ba59abbe56e057f20f883e', '3', '2018-11-09', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teachers_tbl`
--

CREATE TABLE `teachers_tbl` (
  `teachers_id` int(10) UNSIGNED NOT NULL,
  `teachers_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teachers_tbl`
--

INSERT INTO `teachers_tbl` (`teachers_id`, `teachers_name`, `teachers_phone`, `teachers_address`, `teachers_department`, `teachers_image`, `created_at`, `updated_at`) VALUES
(3, 'Reayzul Haq', '01765444', 'cumilla', '1', 'image/Vpc59eoS9EIu4jEoyMlq.jpg', NULL, NULL),
(4, 'Palash Roy', '0811111', 'dhaka', '2', 'image/0hDUbcxep1qgmZrgFyIP.jpg', NULL, NULL),
(5, 'Susmoy Bhowmik', '1110099', 'ctg', '3', 'image/8fAHmRTXYRiBgIgXp0Ro.jpeg', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_tbl`
--
ALTER TABLE `student_tbl`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `teachers_tbl`
--
ALTER TABLE `teachers_tbl`
  ADD PRIMARY KEY (`teachers_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student_tbl`
--
ALTER TABLE `student_tbl`
  MODIFY `student_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `teachers_tbl`
--
ALTER TABLE `teachers_tbl`
  MODIFY `teachers_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
